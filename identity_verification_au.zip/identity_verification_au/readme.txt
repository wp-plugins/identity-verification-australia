=== Identity Verification Australia ===
Contributors: didier, identityverification
Tags: Identity Verification,Verification,Australia,Identity,Identity Verification Australia
Requires at least: 3.9
Tested up to: 4.2-alpha
Stable tag: 1.0

== Description ==

Plugin to Verify Identity Verificaion for Australia Using Driving License/Passport.

= Features =

Identity Verification of a user from Australia can be done easily by providing your Client Id and Client Secret.

== Installation ==

Upload the zip folder of plugin through Admin Panel 

		(OR)

Unzip the folder and place plugin files in /wp-content/plugins/




== How to Use ==

After Activation of the plugin you will get a tab in Left Side of Panel of Admin  as Identity Verification - AU.

When you visit that page you will have form to provide you Client Id and Client Secret.

Use the Short code to get the form in any of the page which can be accessed by a normal User.

Place the thankyou.php in your theme folder


== Short Codes ==

Until API Credentials i.e Client Id and Client Secret Provided you will not get the Short Code.
 Short COde : [IVS_IDENTITY_AU] 
